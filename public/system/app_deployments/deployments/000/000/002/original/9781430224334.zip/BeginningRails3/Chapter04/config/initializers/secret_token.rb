# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
Rails.application.config.secret_token = 'ba00674fc07e3be6351f63a2e7a49800b233acfbd2706e6d4f7a477868c3874505025ac253c5f3efd4e6c1e506cbf7075d7245a26a7e3e00aa3f1e52230ff253'
