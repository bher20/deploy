class Profile < ActiveRecord::Base
  belongs_to :user
end